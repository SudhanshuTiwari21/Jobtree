# Environment Variables Reference

Complete `.env` file template for Jobtree backend.

## 📝 Create Your `.env` File

```bash
cd backend
cp ENV_REFERENCE.md .env
# Then edit .env and fill in your values
```

---

## 🔐 Complete `.env` Template

```bash
# ===========================================
# JOBTREE BACKEND - ENVIRONMENT VARIABLES
# ===========================================
# Copy this to .env and fill in your values
# NEVER commit .env to version control!
# ===========================================

# ===========================================
# SERVER CONFIGURATION
# ===========================================
NODE_ENV=development
PORT=3000

# ===========================================
# DATABASE (Neon PostgreSQL)
# ===========================================
# Option 1: Use DATABASE_URL (RECOMMENDED for Neon)
# Get this from Neon Dashboard → Connection Details → Pooled connection
DATABASE_URL=postgresql://neondb_owner:YOUR_PASSWORD@ep-xxxxx-pooler.ap-southeast-1.aws.neon.tech/jobtree?sslmode=require

# Option 2: Individual params (fallback if not using DATABASE_URL)
# DB_HOST=ep-xxxxx-pooler.ap-southeast-1.aws.neon.tech
# DB_PORT=5432
# DB_NAME=jobtree
# DB_USER=neondb_owner
# DB_PASSWORD=YOUR_PASSWORD
# DB_SSL=true

# Connection Pool Settings (keep low - Neon handles pooling)
DB_POOL_MIN=1
DB_POOL_MAX=5

# ===========================================
# JWT AUTHENTICATION
# ===========================================
# IMPORTANT: Use a strong, random secret (min 32 characters)
# Generate one: openssl rand -base64 32
JWT_SECRET=your-super-secret-jwt-key-change-in-production-min-32-chars
JWT_EXPIRES_IN=7d
JWT_REFRESH_EXPIRES_IN=30d

# ===========================================
# OTP CONFIGURATION
# ===========================================
OTP_LENGTH=6
OTP_EXPIRY_MINUTES=5
OTP_MAX_ATTEMPTS=5
OTP_RESEND_COOLDOWN_SECONDS=30
OTP_MAX_RESEND_ATTEMPTS=3

# ===========================================
# MSG91 (SMS Provider for India)
# ===========================================
# Get credentials from: https://dashboard.msg91.com
MSG91_AUTH_KEY=your_msg91_auth_key
MSG91_SENDER_ID=JOBTRE
MSG91_TEMPLATE_ID=your_dlt_template_id
MSG91_BASE_URL=https://control.msg91.com/api/v5/otp

# ===========================================
# AWS S3 (Media Storage)
# ===========================================
# Optional: Leave empty for development (mock URLs)
AWS_REGION=ap-south-1
AWS_ACCESS_KEY_ID=your_aws_access_key_id
AWS_SECRET_ACCESS_KEY=your_aws_secret_access_key
AWS_S3_BUCKET=jobtree-media
AWS_PRESIGNED_URL_EXPIRY=3600

# ===========================================
# SECURITY
# ===========================================
BCRYPT_SALT_ROUNDS=10
API_RATE_LIMIT_WINDOW_MS=900000
API_RATE_LIMIT_MAX_REQUESTS=100

# ===========================================
# CORS (Allowed Origins)
# ===========================================
# Comma-separated list of allowed origins
ALLOWED_ORIGINS=http://localhost:3000,http://localhost:8080
```

---

## 🎯 Quick Setup Guide

### Development

```bash
# Minimal .env for development
NODE_ENV=development
PORT=3000
DATABASE_URL=postgresql://user:pass@ep-xxx-pooler.region.aws.neon.tech/jobtree?sslmode=require
JWT_SECRET=dev-secret-change-in-production
```

### Production

```bash
# Production .env (ALL values required/configured)
NODE_ENV=production
PORT=3000
DATABASE_URL=postgresql://neondb_owner:PASSWORD@ep-xxx-pooler.region.aws.neon.tech/jobtree?sslmode=require
JWT_SECRET=<generate-strong-secret-32-chars-min>
MSG91_AUTH_KEY=<your-msg91-key>
MSG91_TEMPLATE_ID=<your-template-id>
AWS_ACCESS_KEY_ID=<optional>
AWS_SECRET_ACCESS_KEY=<optional>
```

---

## 📋 Variable Reference

### Required in Production

| Variable | Description | Example |
|----------|-------------|---------|
| `DATABASE_URL` | Neon pooled connection string | `postgresql://user:pass@host/db?sslmode=require` |
| `JWT_SECRET` | JWT signing secret (min 32 chars) | `openssl rand -base64 32` |

### Required for OTP (Production)

| Variable | Description | Source |
|----------|-------------|--------|
| `MSG91_AUTH_KEY` | MSG91 authentication key | [MSG91 Dashboard](https://dashboard.msg91.com) |
| `MSG91_TEMPLATE_ID` | DLT registered template ID | MSG91 Dashboard |

### Optional

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3000` | Server port |
| `NODE_ENV` | `development` | Environment mode |
| `OTP_LENGTH` | `6` | OTP code length |
| `OTP_EXPIRY_MINUTES` | `5` | OTP validity |
| `DB_POOL_MIN` | `1` | Min database connections |
| `DB_POOL_MAX` | `5` | Max database connections |
| `JWT_EXPIRES_IN` | `7d` | Access token expiry |
| `JWT_REFRESH_EXPIRES_IN` | `30d` | Refresh token expiry |
| `AWS_*` | - | S3 media storage (optional) |

---

## 🔑 Generate Secrets

### JWT Secret

```bash
# Generate strong JWT secret (32+ characters)
openssl rand -base64 32

# Or using Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

---

## ✅ Validation Checklist

Before deploying to production:

- [ ] `NODE_ENV=production`
- [ ] `DATABASE_URL` set (Neon pooled connection)
- [ ] `JWT_SECRET` is 32+ characters, random
- [ ] `MSG91_AUTH_KEY` configured
- [ ] `MSG91_TEMPLATE_ID` configured
- [ ] No default/test values
- [ ] `.env` in `.gitignore` (never commit!)
- [ ] Test database connection works
- [ ] Test OTP sending works














