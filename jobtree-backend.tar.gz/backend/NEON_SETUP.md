# Neon PostgreSQL Setup Guide

Complete guide for setting up Neon PostgreSQL as the primary database for Jobtree.

## 📋 Overview

**Why Neon?**
- Serverless PostgreSQL (scales to zero, scales up automatically)
- Built-in connection pooling
- Automated backups with Point-in-Time Recovery (PITR)
- Branching for safe migrations and testing
- Production-ready with zero infrastructure management

---

## 🚀 Step 1: Create Neon Account & Project

### 1.1 Sign Up

1. Go to [https://neon.tech](https://neon.tech)
2. Sign up with GitHub, Google, or email
3. Verify your email

### 1.2 Create Project

1. Click **"New Project"**
2. Configure:
   - **Project name**: `jobtree-production-db`
   - **PostgreSQL version**: `16` (latest stable)
   - **Region**: `Asia Pacific (Singapore)` or closest to your users
   - **Compute size**: Start with `0.25 CU` (auto-scales)

3. Click **"Create Project"**

---

## 🗄️ Step 2: Configure Database

### 2.1 Default Setup

Neon creates these automatically:
- **Database**: `neondb` (we'll rename to `jobtree`)
- **Branch**: `main`
- **Role**: `neondb_owner`

### 2.2 Create Jobtree Database

In Neon Dashboard → SQL Editor, run:

```sql
-- Create the jobtree database
CREATE DATABASE jobtree;

-- Connect to jobtree (click on it in the sidebar)
-- Then run migrations
```

Or use the Neon CLI:

```bash
# Install Neon CLI
npm install -g neonctl

# Login
neonctl auth

# Create database
neonctl databases create --name jobtree
```

---

## 🔐 Step 3: Get Connection Details

### 3.1 Find Connection String

1. Go to **Dashboard** → **Connection Details**
2. Select:
   - **Database**: `jobtree`
   - **Role**: `neondb_owner`
   - **Connection type**: `Pooled connection` ✅

3. Copy the connection string:

```
postgresql://neondb_owner:************@ep-xxxxx-xxxxx.ap-southeast-1.aws.neon.tech/jobtree?sslmode=require
```

### 3.2 Connection String Format

```
postgresql://[user]:[password]@[host]/[database]?sslmode=require
                │        │         │        │            │
                │        │         │        │            └─ Always required for Neon
                │        │         │        └─ Database name (jobtree)
                │        │         └─ Neon pooler endpoint
                │        └─ Auto-generated password
                └─ Database role/user
```

### 3.3 Pooled vs Direct Connection

| Type | Use Case | Endpoint |
|------|----------|----------|
| **Pooled** (recommended) | Application backend | `ep-xxxxx-pooler.region.aws.neon.tech` |
| **Direct** | Migrations, admin tasks | `ep-xxxxx.region.aws.neon.tech` |

**Always use Pooled connection for the application!**

---

## ⚙️ Step 4: Configure Backend

### 4.1 Environment Variables

Add to your `.env` file:

```bash
# ===========================================
# DATABASE (Neon PostgreSQL)
# ===========================================

# Option 1: Full connection string (RECOMMENDED)
DATABASE_URL=postgresql://neondb_owner:YOUR_PASSWORD@ep-xxxxx-pooler.ap-southeast-1.aws.neon.tech/jobtree?sslmode=require

# Option 2: Individual params (if not using DATABASE_URL)
# DB_HOST=ep-xxxxx-pooler.ap-southeast-1.aws.neon.tech
# DB_PORT=5432
# DB_NAME=jobtree
# DB_USER=neondb_owner
# DB_PASSWORD=YOUR_PASSWORD
# DB_SSL=true

# Pool settings (keep low - Neon handles pooling)
DB_POOL_MIN=1
DB_POOL_MAX=5
```

### 4.2 Run Migrations

```bash
cd backend

# Set DATABASE_URL in environment
export DATABASE_URL="postgresql://neondb_owner:YOUR_PASSWORD@ep-xxxxx-pooler.ap-southeast-1.aws.neon.tech/jobtree?sslmode=require"

# Run migrations
npm run db:migrate
```

### 4.3 Verify Connection

```bash
# Start server
npm run dev

# Check logs for:
# ✓ Database connection established
# Database connected: jobtree
# PostgreSQL version: PostgreSQL 16.x
```

---

## 🔄 Step 5: Enable Backup & Recovery

### 5.1 Automated Backups (Default ON)

Neon automatically:
- Takes continuous WAL backups
- Retains history based on your plan:
  - **Free**: 7 days
  - **Launch**: 7 days
  - **Scale**: 30 days
  - **Business**: 30+ days

### 5.2 Point-in-Time Recovery (PITR)

PITR allows restoring to ANY second within retention period.

**To restore:**

1. Go to **Dashboard** → **Branches**
2. Click **"Restore"** on `main` branch
3. Select timestamp to restore to
4. Confirm restoration

### 5.3 Create Manual Backup (Branch)

For extra safety before risky operations:

```bash
# Create a backup branch
neonctl branches create --name backup-$(date +%Y%m%d) --project-id YOUR_PROJECT_ID
```

Or in Dashboard:
1. **Branches** → **New Branch**
2. Name: `backup-2024-01-15`
3. Parent: `main`
4. Point in time: `Current` or specific timestamp

---

## 🌿 Step 6: Branch Strategy

### 6.1 Recommended Branches

| Branch | Purpose | Usage |
|--------|---------|-------|
| `main` | Production data | Live application |
| `staging` | Pre-production testing | Staging environment |
| `dev-*` | Development/testing | Local development |
| `migration-*` | Test migrations | Before applying to main |

### 6.2 Safe Migration Workflow

```bash
# 1. Create migration branch from main
neonctl branches create --name migration-add-jobs-table --parent main

# 2. Get the branch connection string
neonctl connection-string migration-add-jobs-table

# 3. Test migration on branch
DATABASE_URL="branch-connection-string" npm run db:migrate

# 4. Verify everything works
# 5. If OK, apply to main
DATABASE_URL="main-connection-string" npm run db:migrate

# 6. Delete migration branch
neonctl branches delete migration-add-jobs-table
```

---

## 📊 Step 7: Monitoring

### 7.1 Neon Dashboard Metrics

Monitor in Dashboard → **Monitoring**:
- **Compute hours**: CPU usage
- **Storage**: Database size
- **Connections**: Active connections
- **Query performance**: Slow queries

### 7.2 Application Health Check

Add health endpoint to check database:

```bash
curl http://localhost:3000/api/health

# Response:
{
  "success": true,
  "database": {
    "status": "healthy",
    "latency": 45,
    "pool": {
      "totalConnections": 3,
      "idleConnections": 2,
      "waitingClients": 0
    }
  }
}
```

### 7.3 Set Up Alerts (Recommended)

In Neon Dashboard → **Settings** → **Alerts**:
- Storage usage > 80%
- Compute hours approaching limit
- Connection errors

---

## 🛡️ Step 8: Security Best Practices

### 8.1 Connection Security

✅ **DO:**
- Always use `sslmode=require`
- Use pooled connections for app
- Keep connection string in environment variables
- Rotate passwords periodically

❌ **DON'T:**
- Hardcode credentials in code
- Use direct connections for app traffic
- Share connection strings in logs
- Disable SSL

### 8.2 Access Control

```sql
-- Create read-only role for analytics (optional)
CREATE ROLE jobtree_readonly;
GRANT CONNECT ON DATABASE jobtree TO jobtree_readonly;
GRANT USAGE ON SCHEMA public TO jobtree_readonly;
GRANT SELECT ON ALL TABLES IN SCHEMA public TO jobtree_readonly;
```

### 8.3 IP Allowlisting (Optional)

In Neon Dashboard → **Settings** → **IP Allow**:
- Add your server's IP addresses
- Add your development IPs

---

## 🔧 Step 9: Optimization Tips

### 9.1 Connection Pooling

Neon's pooler handles connection management. Keep your app pool small:

```bash
DB_POOL_MIN=1
DB_POOL_MAX=5
```

### 9.2 Cold Start Handling

Neon compute can scale to zero. Handle cold starts:

```javascript
// Already configured in connection.js
connectionTimeoutMillis: 15000, // 15 seconds for cold start
```

### 9.3 Query Optimization

```sql
-- Check slow queries
SELECT query, calls, mean_time, total_time
FROM pg_stat_statements
ORDER BY mean_time DESC
LIMIT 10;

-- Add indexes for common queries
CREATE INDEX CONCURRENTLY idx_salons_phone 
ON salons(phone_number);
```

---

## 🚨 Disaster Recovery

### Scenario 1: Bad Migration

```bash
# 1. Stop application
# 2. In Neon Dashboard, restore main branch to before migration
# 3. Restart application
# 4. Fix migration script
# 5. Re-apply corrected migration
```

### Scenario 2: Data Corruption

```bash
# 1. Create new branch from point before corruption
neonctl branches create --name recovery --parent main --time "2024-01-15T10:30:00Z"

# 2. Export good data
pg_dump "recovery-connection-string" > backup.sql

# 3. Restore to main or create new main from recovery branch
```

### Scenario 3: Accidental Deletion

```sql
-- Neon retains data within retention window
-- Use PITR to restore to before deletion
-- In Dashboard: Branches → main → Restore → Select timestamp
```

---

## 📝 Quick Reference

### Connection String Template

```
postgresql://[user]:[password]@[endpoint]/jobtree?sslmode=require
```

### Neon CLI Commands

```bash
# Install
npm install -g neonctl

# Login
neonctl auth

# List projects
neonctl projects list

# List branches
neonctl branches list

# Create branch
neonctl branches create --name NAME

# Get connection string
neonctl connection-string BRANCH_NAME

# Delete branch
neonctl branches delete BRANCH_NAME
```

### Environment Variables

```bash
# Required
DATABASE_URL=postgresql://...

# Optional
DB_POOL_MIN=1
DB_POOL_MAX=5
```

---

## ✅ Setup Checklist

- [ ] Created Neon account
- [ ] Created project `jobtree-production-db`
- [ ] Created `jobtree` database
- [ ] Got pooled connection string
- [ ] Added `DATABASE_URL` to `.env`
- [ ] Ran migrations successfully
- [ ] Verified connection in logs
- [ ] Understood backup/PITR options
- [ ] Bookmarked Neon Dashboard

---

## 📚 Resources

- [Neon Documentation](https://neon.tech/docs)
- [Neon CLI Reference](https://neon.tech/docs/reference/neon-cli)
- [PostgreSQL Documentation](https://www.postgresql.org/docs/)
- [Connection Pooling Guide](https://neon.tech/docs/connect/connection-pooling)
- [Branching Guide](https://neon.tech/docs/introduction/branching)














