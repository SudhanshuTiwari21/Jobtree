# Environment Setup Guide

## Switching Between Development and Production

The backend switches between **Development** and **Production** modes using the `NODE_ENV` environment variable.

---

## 🛠️ Method 1: Using `.env` File (Recommended)

### Development Mode

In your `.env` file (or leave it unset - defaults to development):

```bash
NODE_ENV=development
```

Or simply don't set it - it defaults to `development`.

### Production Mode

In your `.env` file:

```bash
NODE_ENV=production
```

---

## 🚀 Method 2: Using Command Line

### Development Mode

```bash
# Linux/Mac
NODE_ENV=development npm run dev

# Or just (defaults to development)
npm run dev
```

### Production Mode

```bash
# Linux/Mac
NODE_ENV=production npm start

# Windows (PowerShell)
$env:NODE_ENV="production"; npm start

# Windows (CMD)
set NODE_ENV=production && npm start
```

---

## 📊 What Changes Between Modes

### Development Mode (`NODE_ENV=development` or unset)

| Feature | Behavior |
|---------|----------|
| **OTP Delivery** | ✅ OTPs logged to console (not sent via SMS) |
| **Error Messages** | ✅ Full error stack traces shown |
| **Logging** | ✅ Detailed console logging (morgan 'dev') |
| **Database Reset** | ✅ Allowed (for testing) |
| **OTP Status Endpoint** | ✅ Available at `/api/auth/otp-status/:phoneNumber` |
| **S3 URLs** | ✅ Mock URLs returned |

### Production Mode (`NODE_ENV=production`)

| Feature | Behavior |
|---------|----------|
| **OTP Delivery** | ✅ OTPs sent via MSG91 (requires credentials) |
| **Error Messages** | ✅ Generic messages only (no stack traces) |
| **Logging** | ✅ Production logging (morgan 'combined') |
| **Database Reset** | ❌ Blocked (safety) |
| **OTP Status Endpoint** | ❌ Returns 404 (security) |
| **Required Env Vars** | ✅ Validated on startup |

---

## 🔐 Environment Variable Priority

1. **Command line** (`NODE_ENV=production npm start`)
2. **`.env` file** (in backend directory)
3. **Default** → `development`

---

## 📝 Complete `.env` Examples

### Development `.env`

```bash
# Server
NODE_ENV=development
PORT=3000

# Database (Neon PostgreSQL - use pooled connection string)
DATABASE_URL=postgresql://user:pass@ep-xxx-pooler.region.aws.neon.tech/jobtree?sslmode=require

# Or use individual params for local PostgreSQL
# DB_HOST=localhost
# DB_PORT=5432
# DB_NAME=jobtree
# DB_USER=postgres
# DB_PASSWORD=postgres

# JWT (use strong secret in production!)
JWT_SECRET=dev-secret-change-in-production

# MSG91 (optional in dev - OTPs will be logged)
# MSG91_AUTH_KEY=
# MSG91_TEMPLATE_ID=

# AWS (optional in dev - URLs will be mocked)
# AWS_ACCESS_KEY_ID=
# AWS_SECRET_ACCESS_KEY=
```

### Production `.env`

```bash
# Server
NODE_ENV=production
PORT=3000

# Database (Neon PostgreSQL - ALWAYS use pooled connection)
DATABASE_URL=postgresql://neondb_owner:PASSWORD@ep-xxx-pooler.ap-southeast-1.aws.neon.tech/jobtree?sslmode=require

# Pool settings (keep low - Neon handles pooling)
DB_POOL_MIN=1
DB_POOL_MAX=5

# JWT (MUST use strong, unique secret, min 32 chars!)
JWT_SECRET=your-super-strong-secret-key-min-32-chars

# MSG91 (REQUIRED in production)
MSG91_AUTH_KEY=your_msg91_auth_key
MSG91_SENDER_ID=JOBTRE
MSG91_TEMPLATE_ID=your_dlt_template_id

# AWS (optional but recommended)
AWS_REGION=ap-south-1
AWS_ACCESS_KEY_ID=your_aws_key
AWS_SECRET_ACCESS_KEY=your_aws_secret
AWS_S3_BUCKET=jobtree-media-prod
```

---

## ✅ Quick Checklist

### Before Running in Production:

- [ ] Set `NODE_ENV=production` in `.env`
- [ ] Set strong `JWT_SECRET` (min 32 characters)
- [ ] Configure `MSG91_AUTH_KEY` and `MSG91_TEMPLATE_ID`
- [ ] Set production database credentials
- [ ] Enable `DB_SSL=true` if using cloud database
- [ ] Remove/comment out any test credentials
- [ ] Test OTP sending works
- [ ] Verify error messages are generic (no stack traces)

---

## 🧪 Testing Mode Switching

### Test Development Mode:

```bash
# Start server
NODE_ENV=development npm run dev

# Send OTP request
curl -X POST http://localhost:3000/api/auth/send-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "9876543210"}'

# Check console - you should see:
# 📱 DEV MODE OTP
# Phone: +919876543210
# OTP: 123456
```

### Test Production Mode:

```bash
# Start server
NODE_ENV=production npm start

# Send OTP request
curl -X POST http://localhost:3000/api/auth/send-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "9876543210"}'

# OTP should be sent via MSG91 (check MSG91 dashboard)
# Console should NOT show the OTP
```

---

## 🚨 Common Issues

### Issue: OTPs still logging in production

**Solution**: Check `NODE_ENV` is set correctly:
```bash
echo $NODE_ENV  # Should show "production"
```

### Issue: MSG91 errors in production

**Solution**: Ensure credentials are set:
```bash
# Check .env file has:
MSG91_AUTH_KEY=your_key
MSG91_TEMPLATE_ID=your_template_id
```

### Issue: Database reset not working

**Solution**: This is intentional! Database reset is disabled in production for safety.

---

## 📚 Additional Resources

- [MSG91 Documentation](https://docs.msg91.com/)
- [Node.js Environment Variables](https://nodejs.org/en/learn/command-line/how-to-read-environment-variables-from-nodejs)
- [dotenv Package](https://www.npmjs.com/package/dotenv)

