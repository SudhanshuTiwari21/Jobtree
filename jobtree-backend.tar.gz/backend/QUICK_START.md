# Quick Start Guide - Backend Setup

Get your Jobtree backend up and running in minutes.

## 🚀 Prerequisites

- Node.js >= 18.0.0
- npm >= 9.0.0
- Neon PostgreSQL account ([neon.tech](https://neon.tech)) OR local PostgreSQL

---

## Step 1: Install Dependencies

```bash
cd backend
npm install
```

This installs all required packages (Express, PostgreSQL, JWT, etc.)

---

## Step 2: Set Up Environment Variables

### 2.1 Create `.env` File

```bash
# Copy the reference file
cp ENV_REFERENCE.md .env

# Or create manually
touch .env
```

### 2.2 Minimal Development `.env`

For testing, you need at minimum:

```bash
# Server
NODE_ENV=development
PORT=3000

# Database (Neon PostgreSQL - get from Neon Dashboard)
DATABASE_URL=postgresql://user:password@ep-xxx-pooler.region.aws.neon.tech/jobtree?sslmode=require

# JWT (generate a secret: openssl rand -base64 32)
JWT_SECRET=dev-secret-change-in-production-min-32-characters
```

**To get DATABASE_URL:**
1. Go to [neon.tech](https://neon.tech) and sign up/login
2. Create a project
3. Create a database named `jobtree`
4. Go to Connection Details → Copy **Pooled connection** string
5. Paste it as `DATABASE_URL` in `.env`

---

## Step 3: Set Up Database

### Option A: Using Neon PostgreSQL (Recommended)

1. **Create Neon Account & Project**
   - Sign up at [neon.tech](https://neon.tech)
   - Create project: `jobtree-dev`
   - Create database: `jobtree`
   - Copy the **pooled** connection string to `.env`

2. **Run Migrations**
   ```bash
   npm run db:migrate
   ```

   Expected output:
   ```
   Starting database migrations...
   Running migration: create_uuid_extension
   ✓ Migration completed: create_uuid_extension
   Running migration: create_salons_table
   ✓ Migration completed: create_salons_table
   ...
   All migrations completed successfully!
   ```

### Option B: Using Local PostgreSQL

1. **Install PostgreSQL** (if not installed)
   ```bash
   # macOS
   brew install postgresql
   brew services start postgresql
   
   # Linux
   sudo apt-get install postgresql
   sudo systemctl start postgresql
   ```

2. **Create Database**
   ```bash
   createdb jobtree
   # Or using psql
   psql -U postgres -c "CREATE DATABASE jobtree;"
   ```

3. **Update `.env`**
   ```bash
   DB_HOST=localhost
   DB_PORT=5432
   DB_NAME=jobtree
   DB_USER=postgres
   DB_PASSWORD=your_password
   DB_SSL=false
   ```

4. **Run Migrations**
   ```bash
   npm run db:migrate
   ```

---

## Step 4: Start the Server

### Development Mode (with hot reload)

```bash
npm run dev
```

### Production Mode

```bash
npm start
```

**Expected output:**
```
🚀 Server running on port 3000 in development mode
📡 API available at http://localhost:3000/api
❤️  Health check: http://localhost:3000/api/health
```

---

## Step 5: Test the Setup

### 5.1 Health Check

```bash
# Basic health
curl http://localhost:3000/api/health

# Detailed health (includes database)
curl http://localhost:3000/api/health/detailed
```

**Expected response:**
```json
{
  "success": true,
  "message": "Jobtree API is running",
  "timestamp": "2024-01-15T10:30:00.000Z",
  "environment": "development"
}
```

### 5.2 Test OTP Flow (Development Mode)

In development mode, OTPs are logged to console (not sent via SMS).

```bash
# Send OTP
curl -X POST http://localhost:3000/api/auth/send-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "9876543210", "countryCode": "+91"}'
```

**Check your terminal** - you should see:
```
╔══════════════════════════════════════════════════════════════╗
║                    📱 DEV MODE OTP                           ║
╠══════════════════════════════════════════════════════════════╣
║  Phone: +919876543210                                        ║
║  OTP:   123456                                               ║
║  Expires in: 5 minutes                                       ║
╚══════════════════════════════════════════════════════════════╝
```

```bash
# Verify OTP (use the OTP from console)
curl -X POST http://localhost:3000/api/auth/verify-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "9876543210", "otp": "123456"}'
```

**Expected response:**
```json
{
  "success": true,
  "message": "Account created successfully",
  "isNewUser": true,
  "accessToken": "eyJhbGci...",
  "refreshToken": "eyJhbGci...",
  "salon": {
    "id": "uuid",
    "phoneNumber": "9876543210"
  }
}
```

---

## 🎯 Quick Setup Checklist

- [ ] Node.js >= 18 installed (`node --version`)
- [ ] Dependencies installed (`npm install`)
- [ ] `.env` file created with `DATABASE_URL` and `JWT_SECRET`
- [ ] Neon database created OR local PostgreSQL running
- [ ] Migrations run successfully (`npm run db:migrate`)
- [ ] Server starts without errors (`npm run dev`)
- [ ] Health check returns 200 (`curl http://localhost:3000/api/health`)
- [ ] OTP flow works (check console for OTP in dev mode)

---

## 🔧 Common Issues & Solutions

### Issue: "Cannot find module 'pg'"

**Solution:**
```bash
npm install
```

### Issue: "Database connection failed"

**Solutions:**
1. Check `DATABASE_URL` in `.env` is correct
2. For Neon: Ensure you're using the **pooled** connection string
3. For local: Ensure PostgreSQL is running
   ```bash
   # macOS
   brew services start postgresql
   
   # Check connection
   psql -U postgres -d jobtree
   ```

### Issue: "Migration failed: relation already exists"

**Solution:** Migrations are idempotent - this is OK! The table already exists.

### Issue: "Port 3000 already in use"

**Solution:**
```bash
# Change port in .env
PORT=3001

# Or kill process on port 3000
# macOS/Linux
lsof -ti:3000 | xargs kill -9
```

### Issue: "JWT_SECRET too weak"

**Solution:**
```bash
# Generate a strong secret
openssl rand -base64 32

# Add to .env
JWT_SECRET=<generated-secret>
```

---

## 📚 Next Steps

1. **Set up MSG91** (for production OTP sending):
   - Get credentials from [MSG91 Dashboard](https://dashboard.msg91.com)
   - Add to `.env`: `MSG91_AUTH_KEY`, `MSG91_TEMPLATE_ID`

2. **Test API endpoints:**
   - See `README.md` for complete API documentation
   - Use Postman or curl to test endpoints

3. **Set up AWS S3** (optional, for media storage):
   - Create S3 bucket
   - Add credentials to `.env`

4. **Read documentation:**
   - `README.md` - Complete API docs
   - `NEON_SETUP.md` - Neon database setup
   - `ENVIRONMENT_SETUP.md` - Environment configuration

---

## 🆘 Need Help?

- Check logs in terminal for error messages
- Verify all environment variables are set
- Test database connection separately
- Check [Neon Documentation](https://neon.tech/docs) for database issues

