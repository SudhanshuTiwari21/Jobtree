# Jobtree Backend API

Production-ready backend for the Jobtree salon hiring platform. Built with Node.js, Express, and PostgreSQL.

## 🚀 Features

- **OTP Authentication**: Phone number + OTP based authentication (no passwords)
- **MSG91 Integration**: Reliable SMS delivery for India
- **JWT Tokens**: Secure access and refresh token system
- **Progressive Onboarding**: Salon profiles can be created with minimal data
- **S3 Media Upload**: Presigned URLs for direct-to-S3 uploads
- **Rate Limiting**: Protection against abuse
- **Security**: Helmet, CORS, input validation

## 📋 Prerequisites

- Node.js >= 18.0.0
- Neon PostgreSQL account ([neon.tech](https://neon.tech))
- npm >= 9.0.0
- MSG91 account (for production SMS)

## 🛠️ Installation

### 1. Clone and Install Dependencies

```bash
cd backend
npm install
```

### 2. Configure Environment

```bash
# Copy the example environment file
cp .env.example .env

# Edit .env with your values
nano .env
```

### 3. Setup Neon PostgreSQL Database

See [NEON_SETUP.md](./NEON_SETUP.md) for complete setup guide.

**Quick setup:**
1. Create account at [neon.tech](https://neon.tech)
2. Create project `jobtree-production-db`
3. Create database `jobtree`
4. Copy the **pooled** connection string
5. Add to `.env`:
   ```bash
   DATABASE_URL=postgresql://user:pass@host/jobtree?sslmode=require
   ```
6. Run migrations:
   ```bash
   npm run db:migrate
   ```

### 4. Start the Server

```bash
# Development mode (with hot reload)
npm run dev

# Production mode
npm start
```

## 📱 SMS Provider Configuration

### MSG91 (Primary - Recommended for India)

1. Create an account at [MSG91](https://msg91.com)
2. Get your Auth Key from Dashboard > API
3. Create a DLT-registered template for OTP
4. Configure environment variables:

```bash
MSG91_AUTH_KEY=your_msg91_auth_key
MSG91_SENDER_ID=JOBTRE
MSG91_TEMPLATE_ID=your_dlt_template_id
MSG91_BASE_URL=https://control.msg91.com/api/v5/otp
```

### MSG91 DLT Template Format

Your MSG91 template should follow this format:
```
Your Jobtree verification code is: {otp}. This code expires in 5 minutes. Do not share this code.
```

### Provider Priority

| Environment | Provider |
|-------------|----------|
| Development | Console (OTPs logged to terminal) |
| Production | MSG91 |

## 🗄️ Database (Neon PostgreSQL)

### Features

- **Serverless**: Scales to zero, auto-scales up
- **Automated Backups**: Daily snapshots, 7+ days retention
- **Point-in-Time Recovery**: Restore to any second
- **Branching**: Safe migration testing
- **Connection Pooling**: Built-in pooler

### Tables

1. **salons** - Main identity table for salon owners
2. **otp_requests** - OTP storage with hashing and expiry
3. **salon_media** - S3-backed media references
4. **salon_policies** - Optional policies and working hours
5. **salon_verification_docs** - KYC documents (masked data only)
6. **refresh_tokens** - JWT refresh token storage

### Run Migrations

```bash
# Create all tables
npm run db:migrate

# Reset database (development only - blocked in production)
npm run db:reset
```

## 🔌 API Endpoints

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/send-otp` | Send OTP to phone number |
| POST | `/api/auth/resend-otp` | Resend OTP |
| POST | `/api/auth/verify-otp` | Verify OTP and login/signup |
| POST | `/api/auth/refresh` | Refresh access token |
| POST | `/api/auth/logout` | Logout (revoke tokens) |

### Salon Profile

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/salon/me` | Get current salon profile |
| PATCH | `/api/salon/profile` | Update profile (partial) |
| GET | `/api/salon/completion` | Get profile completion status |

### Media

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/salon/media/presign` | Get presigned upload URL |
| POST | `/api/salon/media` | Save media record |
| DELETE | `/api/salon/media/:id` | Delete media |

## 📝 API Usage Examples

### Send OTP

```bash
curl -X POST http://localhost:3000/api/auth/send-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "9876543210", "countryCode": "+91"}'
```

Response:
```json
{
  "success": true,
  "message": "OTP sent successfully",
  "expiresIn": 300
}
```

### Verify OTP

```bash
curl -X POST http://localhost:3000/api/auth/verify-otp \
  -H "Content-Type: application/json" \
  -d '{"phoneNumber": "9876543210", "otp": "123456"}'
```

Response:
```json
{
  "success": true,
  "message": "Login successful",
  "isNewUser": false,
  "accessToken": "eyJhbGciOiJIUzI1NiIs...",
  "refreshToken": "eyJhbGciOiJIUzI1NiIs...",
  "expiresIn": "7d",
  "salon": {
    "id": "uuid",
    "phoneNumber": "9876543210",
    "salonName": "Style Hub"
  }
}
```

### Get Profile (Protected)

```bash
curl -X GET http://localhost:3000/api/salon/me \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN"
```

### Update Profile (Protected)

```bash
curl -X PATCH http://localhost:3000/api/salon/profile \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"salonName": "Style Hub", "city": "Mumbai"}'
```

### Get Media Upload URL (Protected)

```bash
curl -X POST http://localhost:3000/api/salon/media/presign \
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"mediaType": "photo", "contentType": "image/jpeg", "filename": "salon.jpg"}'
```

## 🔒 Security

- **OTP Hashing**: OTPs are hashed with bcrypt before storage
- **OTP Never Logged in Production**: OTPs are only logged in development mode
- **JWT**: Access tokens (7d) and refresh tokens (30d)
- **Rate Limiting**: 
  - General: 100 requests per 15 minutes
  - OTP: 5 requests per 15 minutes
- **Input Validation**: All inputs validated using express-validator
- **Helmet**: Security headers enabled
- **CORS**: Configurable allowed origins
- **Provider Errors Hidden**: SMS provider errors never exposed to clients

## 🧪 Development Mode

In development mode:
- OTPs are logged to console (never sent via SMS)
- S3 URLs are mocked
- Database operations work normally

```
╔══════════════════════════════════════════════════════════════╗
║                    📱 DEV MODE OTP                           ║
╠══════════════════════════════════════════════════════════════╣
║  Phone: +919876543210                                        ║
║  OTP:   123456                                               ║
║  Expires in: 5 minutes                                       ║
╚══════════════════════════════════════════════════════════════╝
```

## 📁 Project Structure

```
backend/
├── src/
│   ├── config/
│   │   └── index.js              # Configuration management
│   ├── database/
│   │   ├── connection.js         # PostgreSQL connection pool
│   │   ├── migrate.js            # Database migrations
│   │   └── reset.js              # Database reset (dev only)
│   ├── middleware/
│   │   ├── auth.js               # JWT authentication
│   │   ├── errorHandler.js       # Error handling
│   │   ├── security.js           # Security middleware
│   │   └── validation.js         # Input validation
│   ├── routes/
│   │   ├── authRoutes.js         # Auth endpoints
│   │   ├── salonRoutes.js        # Salon endpoints
│   │   └── index.js              # Route aggregator
│   ├── services/
│   │   ├── authService.js        # Authentication logic
│   │   ├── otpService.js         # OTP generation & verification
│   │   ├── otpSenderService.js   # SMS delivery abstraction (MSG91/Twilio)
│   │   ├── s3Service.js          # AWS S3 operations
│   │   └── salonService.js       # Salon business logic
│   ├── utils/
│   │   └── logger.js             # Winston logger
│   └── server.js                 # Express app entry point
├── package.json
└── README.md
```

## 🚀 Deployment

### Environment Variables (Production)

**Required:**
- `DATABASE_URL` (Neon pooled connection string)
- `JWT_SECRET` (use a strong, unique secret, min 32 chars)

**SMS Provider:**
- `MSG91_AUTH_KEY`, `MSG91_TEMPLATE_ID`

**Optional:**
- `AWS_*` credentials for S3

### Health Checks

```bash
# Basic health
curl http://localhost:3000/api/health

# Detailed health with database status
curl http://localhost:3000/api/health/detailed
```

### Docker

```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

## 🔧 Architecture Notes

### OTP Sender Service

The `otpSenderService.js` provides an abstraction for SMS delivery:

```javascript
// Usage (internal)
await otpSender.sendOtp('9876543210', '123456', '91');
```

**Features:**
- Automatic provider selection based on environment
- Console logging in development
- MSG91 in production
- Phone number masking for logs
- Error isolation (provider errors don't leak to clients)

## 📜 License

ISC
