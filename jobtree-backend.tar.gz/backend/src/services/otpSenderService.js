/**
 * OTP Sender Service
 * 
 * Provider-agnostic SMS delivery abstraction.
 * Currently supports MSG91 for India.
 * 
 * In development mode, OTPs are logged to console.
 * In production mode, OTPs are sent via MSG91.
 */

import config from '../config/index.js';
import logger from '../utils/logger.js';

// SMS Provider Types
const SMS_PROVIDER = {
  MSG91: 'msg91',
  CONSOLE: 'console', // Dev mode
};

class OTPSenderService {
  constructor() {
    this.provider = this.determineProvider();
    logger.info(`OTP Sender initialized with provider: ${this.provider}`);
  }

  /**
   * Determine which SMS provider to use based on environment and configuration
   * @returns {string} Provider identifier
   */
  determineProvider() {
    // Development mode always uses console
    if (config.env !== 'production') {
      return SMS_PROVIDER.CONSOLE;
    }

    // Check MSG91 credentials
    if (config.msg91.authKey && config.msg91.templateId) {
      return SMS_PROVIDER.MSG91;
    }

    // No provider configured - will log warning and use console
    logger.warn('No SMS provider configured. OTPs will be logged to console.');
    return SMS_PROVIDER.CONSOLE;
  }

  /**
   * Send OTP to a phone number
   * @param {string} phoneNumber - 10-digit phone number (without country code)
   * @param {string} otp - Generated OTP
   * @param {string} countryCode - Country code (default: 91)
   * @returns {Promise<void>}
   */
  async sendOtp(phoneNumber, otp, countryCode = '91') {
    // Sanitize phone number - remove leading zeros and non-digits
    const sanitizedPhone = phoneNumber.replace(/\D/g, '').replace(/^0+/, '');
    
    // Format full number without + sign (MSG91 requires this format)
    const fullNumber = `${countryCode.replace('+', '')}${sanitizedPhone}`;

    switch (this.provider) {
      case SMS_PROVIDER.MSG91:
        await this.sendViaMSG91(fullNumber, otp);
        break;
      
      case SMS_PROVIDER.CONSOLE:
      default:
        this.logToConsole(fullNumber, otp);
        break;
    }
  }

  /**
   * Send OTP via MSG91
   * @param {string} mobile - Full mobile number (e.g., "919876543210")
   * @param {string} otp - OTP to send
   * @returns {Promise<void>}
   */
  async sendViaMSG91(mobile, otp) {
    const { baseUrl, authKey, senderId, templateId } = config.msg91;

    const requestBody = {
      template_id: templateId,
      mobile: mobile,
      otp: otp,
      sender: senderId,
    };

    try {
      const response = await fetch(baseUrl, {
        method: 'POST',
        headers: {
          'authkey': authKey,
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: JSON.stringify(requestBody),
      });

      const data = await response.json();

      // MSG91 returns type: "success" for successful requests
      if (response.ok && data.type === 'success') {
        logger.info(`MSG91: OTP sent successfully to ${this.maskPhone(mobile)}`);
        return;
      }

      // Log error internally but don't expose to client
      logger.error('MSG91 Error:', {
        status: response.status,
        message: data.message || 'Unknown error',
        code: data.code,
        // Never log the OTP in production
      });

      throw new Error('Failed to send OTP. Please try again.');

    } catch (error) {
      // Network errors or other failures
      if (error.message === 'Failed to send OTP. Please try again.') {
        throw error;
      }

      logger.error('MSG91 Request Failed:', {
        error: error.message,
        mobile: this.maskPhone(mobile),
      });

      throw new Error('Failed to send OTP. Please try again.');
    }
  }

  /**
   * Log OTP to console (development mode)
   * @param {string} phoneNumber - Phone number
   * @param {string} otp - OTP
   */
  logToConsole(phoneNumber, otp) {
    // Only log in non-production environments
    if (config.env === 'production') {
      logger.error('SECURITY: Attempted to log OTP in production mode');
      return;
    }

    const formattedNumber = phoneNumber.startsWith('+') ? phoneNumber : `+${phoneNumber}`;
    
    logger.warn(`[DEV MODE] OTP for ${formattedNumber}: ${otp}`);
    
    console.log(`
╔══════════════════════════════════════════════════════════════╗
║                    📱 DEV MODE OTP                           ║
╠══════════════════════════════════════════════════════════════╣
║  Phone: ${formattedNumber.padEnd(52)}║
║  OTP:   ${otp.padEnd(52)}║
║  Expires in: ${config.otp.expiryMinutes} minutes                                      ║
╚══════════════════════════════════════════════════════════════╝
    `);
  }

  /**
   * Mask phone number for logging (privacy)
   * @param {string} phone - Phone number
   * @returns {string} Masked phone
   */
  maskPhone(phone) {
    if (!phone || phone.length < 6) return '****';
    return phone.slice(0, 4) + '****' + phone.slice(-2);
  }

  /**
   * Get current provider name (for debugging)
   * @returns {string} Provider name
   */
  getProvider() {
    return this.provider;
  }

  /**
   * Check if SMS provider is properly configured
   * @returns {boolean} Configuration status
   */
  isConfigured() {
    return this.provider !== SMS_PROVIDER.CONSOLE || config.env !== 'production';
  }
}

// Export singleton instance
export default new OTPSenderService();
